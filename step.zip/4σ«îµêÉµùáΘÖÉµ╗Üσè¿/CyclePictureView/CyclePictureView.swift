//
//  CyclePictureView.swift
//  CyclePictureView
//
//  Created by wl on 15/11/7.
//  Copyright © 2015年 wl. All rights reserved.
//

import UIKit

class CyclePictureView: UIView, UICollectionViewDelegate, UICollectionViewDataSource {

     // MARK: - 属性接口
    
    /// 存放本地图片名称的数组
    var localImageArray: [String]? {
        didSet {
            self.actualItemCount =  (self.needEndlessScroll ?? false) ? localImageArray!.count * 150 : localImageArray!.count
            //重新加载数据
            self.collectionView.reloadData()
            self.showFirstImagePage()
        }

    }
    /// 存放网络图片路径的数组
    var imageURLArray: [String]? {
        didSet {
            self.actualItemCount =  (self.needEndlessScroll ?? false) ? imageURLArray!.count * 150 : imageURLArray!.count
            //重新加载数据
            self.collectionView.reloadData()
            self.showFirstImagePage()
        }
    }
    /// 图片的描述文字
    var imageDetailArray: [String]?
    
    // 一些cell文字描述的属性
    var detailLableTextFont: UIFont?
    var detailLableTextColor: UIColor?
    var detailLableBackgroundColor: UIColor?
    var detailLableHeight: CGFloat?
    var detailLableAlpha: CGFloat?
    
    /// 是否开启自动滚动,默认是ture
    var autoScroll: Bool? {
        didSet {
            self.timer?.invalidate() //先取消先前定时器
            if autoScroll! {
                self.setupTimer()   //重新设置定时器
            }
        }
    }
    /// 开启自动滚动后，自动翻页的时间，默认为2秒
    var timeInterval: Double?
    /// 是否开启无限滚动模式
    var needEndlessScroll: Bool?
    
     // MARK: - 内部属性
    
    // 用于无限滚动中，无限滚动原理就是让collectionView的内容扩大,也就是说让cell变多
    var actualItemCount: Int = 0

    var collectionView: UICollectionView!
    let cellID: String = "CyclePictureCell"
    var flowLayout: UICollectionViewFlowLayout?
    /// 控制自动滚动的定时器
    var timer: NSTimer?
    
    override var frame: CGRect {
        didSet {
            self.flowLayout?.itemSize = frame.size
        }
    }
     // MARK: - 初始化方法
    
    init(frame: CGRect, localImageArray: [String]?) {
        
        super.init(frame: frame)
        self.initSomething()
        self.setupCollectionView()
        
        if let array = localImageArray {
           self.localImageArray = array
        }
    }
    
    init(frame: CGRect, imageURLArray: [String]?) {
        
        super.init(frame: frame)
        self.setupCollectionView()
        self.initSomething()
        
        if let array = imageURLArray {
            self.imageURLArray = array
        }
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit{
        print("CyclePictureView---deinit")
    }
    
    /**
    解决定时器强引用视图，导致视图不被释放
    */
    override func willMoveToSuperview(newSuperview: UIView?) {
        super.willMoveToSuperview(newSuperview)
        guard let _ = newSuperview else {
            self.timer?.invalidate()
            self.timer = nil
            return
        }
    }
    
    
    /**
    初始化一些默认的设置(属性)
    */
    private func initSomething() {
        autoScroll = true
        timeInterval = 2.0
        needEndlessScroll = true
    }
    /**
    设置CollectionView相关内容
    */
    private func setupCollectionView() {
        
        // 初始化布局
        let flowLayout =  UICollectionViewFlowLayout()
        flowLayout.itemSize = frame.size
        flowLayout.minimumLineSpacing = 0
        flowLayout.scrollDirection = .Horizontal
        self.flowLayout = flowLayout
        
        let collectionView = UICollectionView(frame: self.bounds, collectionViewLayout: flowLayout)
        collectionView.backgroundColor = UIColor.orangeColor()
        collectionView.showsVerticalScrollIndicator = false
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.bounces = false
        collectionView.pagingEnabled = true
        // TODO: view充当数据源和代理，感觉不符合逻辑，待修改
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.registerClass(CyclePictureCell.self, forCellWithReuseIdentifier: cellID)
        self.addSubview(collectionView)

        self.collectionView = collectionView
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()

        self.collectionView.frame = self.bounds
    }
    
    /**
    显示第一张图片
    */
    private func showFirstImagePage() {
        var newIndex = 0
        if (needEndlessScroll ?? false) {
            newIndex = actualItemCount / 2
        }
        self.collectionView.scrollToItemAtIndexPath(NSIndexPath(forItem: newIndex, inSection: 0), atScrollPosition: .None, animated: false)
    }
    
    /**
    设置定时器
    */
    private func setupTimer() {
        let timer = NSTimer(timeInterval: timeInterval ?? 2.0, target: self, selector: Selector("changePicture"), userInfo: nil, repeats: true)
        NSRunLoop.mainRunLoop().addTimer(timer, forMode: NSRunLoopCommonModes)
        self.timer = timer
    }
    
    /**
    定时器回调方法，用于自动翻页
    */
    func changePicture() {
        
        guard actualItemCount != 0 else {
            return
        }
        
        let currentIndex = Int(self.collectionView.contentOffset.x / self.flowLayout!.itemSize.width)
        let nextIndex = currentIndex + 1
        if nextIndex >= actualItemCount {
            self.showFirstImagePage()
        }else {
        
            self.collectionView.scrollToItemAtIndexPath(NSIndexPath(forItem: nextIndex, inSection: 0), atScrollPosition: .None, animated: true)
        }
        
    }
    
    // MARK: - collectionView 数据源
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return self.actualItemCount
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier(cellID, forIndexPath: indexPath) as! CyclePictureCell
        
        if let array = self.localImageArray {
            let actualItemIndex = indexPath.item % array.count
            cell.imagePath = array[actualItemIndex]
        }
        if let array = self.imageURLArray {
            let actualItemIndex = indexPath.item % array.count
            cell.imageURL = array[actualItemIndex]
        }
        if let array = self.imageDetailArray {
            let actualItemIndex = indexPath.item % array.count
            cell.imageDetail = array[actualItemIndex]
            // TODO: 好恶心的判决金字塔，不知道有什么办法解决
            if let font = self.detailLableTextFont {
                cell.detailLableTextFont = font
            }
            if let color = self.detailLableTextColor {
                cell.detailLableTextColor = color
            }
            if let backgroundColor = self.detailLableBackgroundColor {
                cell.detailLableBackgroundColor = backgroundColor
            }
            if let height = self.detailLableHeight {
                cell.detailLableHeight = height
            }
            if let aphla = self.detailLableAlpha {
                cell.detailLableAlpha = aphla
            }
            
        }
        return cell
    }
    
     // MARK: - scrollView 代理
    func scrollViewWillBeginDragging(scrollView: UIScrollView) {
        if (self.autoScroll ?? false) {
            self.timer?.invalidate()
            self.timer = nil
        }
    }
    
    func scrollViewDidEndDragging(scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        if (self.autoScroll ?? false) {
            self.setupTimer()
        }
    }

}

extension CyclePictureView {
 
}
