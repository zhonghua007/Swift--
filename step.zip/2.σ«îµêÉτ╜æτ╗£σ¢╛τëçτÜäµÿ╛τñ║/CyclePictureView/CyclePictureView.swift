//
//  CyclePictureView.swift
//  CyclePictureView
//
//  Created by wl on 15/11/7.
//  Copyright © 2015年 wl. All rights reserved.
//

import UIKit

class CyclePictureView: UIView, UICollectionViewDelegate, UICollectionViewDataSource {

     // MARK: - 属性接口
    
    /// 存放本地图片名称的数组
    var localImageArray: [String]? {
        didSet {
            //重新加载数据
            self.collectionView.reloadData()
        }

    }
    /// 存放网络图片路径的数组
    var imageURLArray: [String]? {
        didSet {
            //重新加载数据
            self.collectionView.reloadData()
        }
        
    }

     // MARK: - 内部属性
    var collectionView: UICollectionView!
    let cellID: String = "CyclePictureCell"
     // MARK: - 初始化方法
    
    init(frame: CGRect, localImageArray: [String]?) {
        super.init(frame: frame)

        self.setupCollectionView()
        
        if let array = localImageArray {
           self.localImageArray = array
        }
    }
    
    init(frame: CGRect, imageURLArray: [String]?) {
        super.init(frame: frame)
        
        self.setupCollectionView()
        
        if let array = imageURLArray {
            self.imageURLArray = array
        }
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit{
        print("CyclePictureView---deinit")
    }
    
    private func setupCollectionView() {
        
        // 初始化布局
        let flowLayout =  UICollectionViewFlowLayout()
        flowLayout.itemSize = frame.size
        flowLayout.minimumLineSpacing = 0
        flowLayout.scrollDirection = .Horizontal
        
        let collectionView = UICollectionView(frame: self.bounds, collectionViewLayout: flowLayout)
        collectionView.showsVerticalScrollIndicator = false
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.pagingEnabled = true
        // TODO: view充当数据源和代理，感觉不符合逻辑，待修改
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.registerClass(CyclePictureCell.self, forCellWithReuseIdentifier: cellID)
        self.addSubview(collectionView)

        self.collectionView = collectionView
    }
    
    // MARK: - collectionView 数据源
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        if let count = self.localImageArray?.count {
            return count
        }
        if let count = self.imageURLArray?.count {
            return count
        }
        
        return 0
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier(cellID, forIndexPath: indexPath) as! CyclePictureCell
        
        if let array = self.localImageArray {
            cell.imagePath = array[indexPath.item]
        }
        if let array = self.imageURLArray {
            cell.imageURL = array[indexPath.item]
        }
        return cell
    }

}

extension CyclePictureView {
 
}
