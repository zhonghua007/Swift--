//
//  WebPictureController.swift
//  CyclePictureView
//
//  Created by wl on 15/11/7.
//  Copyright © 2015年 wl. All rights reserved.
//

import UIKit

class WebPictureController: UIViewController {

    var dataArray: NSArray? = {
        let path = NSBundle.mainBundle().pathForResource("Image.plist", ofType: nil)!
        var array = NSArray(contentsOfFile: path)
        return array
        }()
    
    var imageURLArray: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for i in 0..<dataArray!.count {
            imageURLArray.append(dataArray![i]["image"] as! String)
        }
        
        let cyclePictureView = CyclePictureView(frame: CGRectMake(0, 100, self.view.frame.width, 200), localImageArray: nil)
        cyclePictureView.backgroundColor = UIColor.blackColor()
        cyclePictureView.imageURLArray = imageURLArray
        self.view.addSubview(cyclePictureView)
    }
    
    deinit {
        print("WebPictureController----deinit")
    }

}
