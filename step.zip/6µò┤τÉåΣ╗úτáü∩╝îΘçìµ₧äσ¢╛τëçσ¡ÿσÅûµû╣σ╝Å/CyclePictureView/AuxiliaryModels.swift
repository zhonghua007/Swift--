//
//  AuxiliaryModels.swift
//  CyclePictureView
//
//  Created by wl on 15/11/8.
//  Copyright © 2015年 wl. All rights reserved.
//

import Foundation


enum ImageSource {
    case Local(name: String)
    case Network(urlStr: String)
}

enum ImageType {
    case Local
    case Network
}

struct ImageBox {
    var imageType: ImageType
    var imageArray: [ImageSource]
    
    init(imageType: ImageType, imageArray: [String]) {
        
        self.imageType = imageType
        self.imageArray = []
        
        switch imageType {
        case .Local:
            for str in imageArray {
                self.imageArray.append(ImageSource.Local(name: str))
            }
        case .Network:
            for str in imageArray {
                self.imageArray.append(ImageSource.Network(urlStr: str))
            }
        }
    }
    
    subscript (index: Int) -> ImageSource {
        get {
            return self.imageArray[index]
        }
    }
}


