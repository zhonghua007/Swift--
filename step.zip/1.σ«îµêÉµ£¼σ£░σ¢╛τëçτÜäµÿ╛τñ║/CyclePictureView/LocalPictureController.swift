//
//  LocalPictureController.swift
//  CyclePictureView
//
//  Created by wl on 15/11/7.
//  Copyright © 2015年 wl. All rights reserved.
//

import UIKit

class LocalPictureController: UIViewController {

    var localImageArray: [String] = {
        
        var array: [String] = []
        for i in 1...5 {
            array.append("\(i)")
        }
        return array
        }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let cyclePictureView = CyclePictureView(frame: CGRectMake(0, 100, self.view.frame.width, 200), localImageArray: nil)
        cyclePictureView.backgroundColor = UIColor.blackColor()
        cyclePictureView.localImageArray = localImageArray
        self.view.addSubview(cyclePictureView)
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
