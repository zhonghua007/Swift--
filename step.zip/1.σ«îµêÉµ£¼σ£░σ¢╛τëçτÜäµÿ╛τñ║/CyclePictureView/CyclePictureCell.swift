//
//  CyclePictureCell.swift
//  CyclePictureView
//
//  Created by wl on 15/11/7.
//  Copyright © 2015年 wl. All rights reserved.
//

import UIKit

class CyclePictureCell: UICollectionViewCell {

//    var dataModel
    var imagePath: String? {
        
        didSet {
            self.imageView.image = UIImage(named: imagePath!)
        }
    }
    
    private var imageView: UIImageView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setupImageView()
    }
    
    private func setupImageView() {
        imageView = UIImageView()
        imageView.contentMode = .ScaleAspectFill
        self.addSubview(imageView)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        imageView.frame = self.bounds
    }
}
