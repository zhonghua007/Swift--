//
//  LocalPictureController.swift
//  CyclePictureView
//
//  Created by wl on 15/11/7.
//  Copyright © 2015年 wl. All rights reserved.
//

import UIKit

class LocalPictureController: UIViewController {
    
    var cyclePictureView: CyclePictureView!
    var localImageArray: [String] = {
        
        var array: [String] = []
        for i in 1...5 {
            array.append("\(i)")
        }
        return array
        }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let cyclePictureView = CyclePictureView(frame: CGRectMake(0, 100, self.view.frame.width, 200), localImageArray: nil)
        cyclePictureView.backgroundColor = UIColor.redColor()
        cyclePictureView.localImageArray = localImageArray
        self.view.addSubview(cyclePictureView)
        self.cyclePictureView = cyclePictureView
    }

    deinit {
        print("LocalPictureController----deinit")
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        self.cyclePictureView.frame = CGRectMake(0, 100, self.view.frame.width, 150)
    }

}
